[![](../../actions/workflows/cpp_cmake.yml/badge.svg)](../../actions)

# Reasonable2D

An OpenGL game engine. Originally a project created at course called "Programowanie Aplikacji Graficznych" (Programming graphic applications) at Lodz University of Technology. It is now my passion project.
