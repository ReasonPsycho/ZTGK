//
// Created by redkc on 23/02/2024.
//

#include "SystemManager.h"

void SystemManager::showImGuiDetails(Camera *camera) {
    ImGuiID dockspace_id = ImGui::GetID("Scene");

}
