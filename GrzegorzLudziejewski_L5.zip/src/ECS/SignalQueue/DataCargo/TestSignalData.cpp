//
// Created by cheily on 21.03.2024.
//

#include "TestSignalData.h"
#include "../Signal.h"

Signal TestSignalData::signal() {
    return {};
}
