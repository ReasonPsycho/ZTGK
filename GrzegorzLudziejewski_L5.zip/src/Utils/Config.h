//
// Created by cheily on 08.04.2024.
//

#pragma once

namespace ztgk::config {

    static bool pause = false;

    static glm::ivec2 window_size = { 1920, 1080 };
    static bool fullscreen = false;

}